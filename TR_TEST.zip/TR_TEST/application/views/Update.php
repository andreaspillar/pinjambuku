<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Welcome to CodeIgniter</title>

</head>
<body>

<div id="container">
 <center>
 <br />
 <br />
 <br />
 <br />
 <br />
 <br />
 <br />
 <br />
 <br />
 <br />
 <br />
 <br />
  <p />	
  <h1>FORM DATA MAHASISWA</h1>
 <form action="<?php echo site_url('Update/update')?>" method="POST" >
  <?php foreach($tbmahasiswa1 as $mhs){?>
 <table border="1" style=" width:25%; text-align:left;" >
 <tr>
  <td>Nim </td>
  <td><input type="text" name="Nim" value="<?php echo $mhs->Nim;?>" style=" width:99%;" placeholder="" /></td>
 </tr>
 <tr>
  <td>Nama</td>
  <td><input type="text" name="Nama" value="<?php echo $mhs->Nama;?>" style=" width:99%;" placeholder=""></td>
 </tr>  
  <tr>
  <td></td>
  <td><input type="submit" name="Simpan" value="Simpan">
  <button type="reset" value="Reset">Reset</button>
   </td>
  </tr>
  </table>
  <?php }?>
 </form>
  
						 <div class="col-md-12" style="margin-top:20px;">
						 <center>
						<table border="1" style=" width:25%; margin-top:20px; text-align:center;" >
						<h1>TABEL DATA MAHASISWA</h1>
								<tr>
								  <th>Nim</th>
								  <th>Nama</th>
								  <th>Aksi</th>
								</tr>
									<?php foreach($tbmahasiswa as $mhs){?>
										 <tr>
											
											 <td><?php echo $mhs->Nim;?></td>
											 <td><?php echo $mhs->Nama;?></td>
											 <td><a href="<?php echo site_url('Welcome/delete_/'.$mhs->Nim);?>"><button class="btn btn-info">Hapus</button></a></td>
										 </tr>
									<?php }?>
						</table>
						
						 </div>
						 
</center>
</div>



</body>
</html>