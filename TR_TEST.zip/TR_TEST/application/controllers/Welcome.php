<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {


	 public function __construct()
	 	{
	 		parent::__construct();
			$this->load->helper('url');
	 		$this->load->Model('Model');
            $this->load->Model('Buku');
         
         
            $this->load->helper('form');
            $this->load->library('form_validation');
            $this->load->library('session');

	 	}


	public function index()
	{
//		$data['students']=$this->Model->get_all();
		$this->load->view('frontpage');
	}
	
	public function add()
	{
		
		$email_st =$this->input->post('email_st');
		$pwd_st =$this->input->post('pwd_st');

            $data = array
				(
					'email_st'   =>$email_st,
					'pwd_st'   => $pwd_st,
					
				);
			$insert= $this->Model->add($data);
            redirect('Welcome/login');
        
	}
	
	public function delete_($no)
	{
	$this->Model->delete_id($no);
	redirect('Welcome');
	}
	
	function signup(){
        $this->load->view('signup');
    }
    function login(){
        $this->load->helper(array('form'));
        $this->load->view('login');
    }
    function login_admin(){
        $this->load->helper(array('form'));
        $this->load->view('login-admin');
    }
    function verify() {

        $this->form_validation->set_rules('username', 'Username', 'trim|required|xss_clean');
        $this->form_validation->set_rules('password', 'Password', 'trim|required|xss_clean');

        if ($this->form_validation->run() != FALSE) {
        if(isset($this->session->userdata['logged_in'])){
        $this->load->view('home-mhs');
        }else{
        $this->load->view('login');
        }
        } else {
        $data = array(
        'username' => $this->input->post('username'),
        'password' => $this->input->post('password')
        );
        $result = $this->Model->login($data);
        if ($result == TRUE) {

        $username = $this->input->post('username');
        $result = $this->Model->read_user_information($username);
        if ($result != false) {
        $session_data = array(
        'username' => $result[0]->email_st,
        'password' => $result[0]->pwd_st,
        );
        // Add user data in session
        $this->session->set_userdata('logged_in', $session_data);
        $this->load->view('home-mhs');
        }
        } else {
        $data = array(
        'error_message' => 'Invalid Username or Password'
        );
        $this->load->view('login', $data);
        }
        }
        }
    
    public function board(){
        $data['buku']=$this->Buku->viewbook();
        $this->load->view('board-mhs',$data);
    }
    

    function verify_admin() {

        $this->form_validation->set_rules('username', 'Username', 'trim|required|xss_clean');
        $this->form_validation->set_rules('password', 'Password', 'trim|required|xss_clean');

        if ($this->form_validation->run() != FALSE) {
        if(isset($this->session->userdata['logged_in'])){
        $data['buku']=$this->Buku->viewbook();
        $this->load->view('home-admin',$data);
        }else{
        $this->load->view('login-admin');
        }
        } else {
        $data = array(
        'username' => $this->input->post('username'),
        'password' => $this->input->post('password')
        );
        $result = $this->Model->login_admin($data);
        if ($result == TRUE) {

        $username = $this->input->post('username');
        $result = $this->Model->read_admin_information($username);
        if ($result != false) {
        $session_data = array(
        'username' => $result[0]->username,
        'password' => $result[0]->password,
        );
        // Add user data in session
        $this->session->set_userdata('logged_in', $session_data);
        $data['buku']=$this->Buku->viewbook();
        $this->load->view('home-admin',$data);
        }
        } else {
        $data = array(
        'error_message' => 'Invalid Username or Password'
        );
        $this->load->view('login-admin', $data);
        }
        }
        }
    

        public function logout() {
        // Removing session data
        $this->session->unset_userdata('logged_in');
        session_destroy();
        redirect('welcome', 'refresh');
        }
    
}
