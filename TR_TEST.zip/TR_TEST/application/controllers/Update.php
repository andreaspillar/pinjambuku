<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Update extends CI_Controller {


	 public function __construct()
	 	{
	 		parent::__construct();
			$this->load->helper('url');
	 		$this->load->Model('Model');
	 	}

	public function index($id)
	{
		$data['tbmahasiswa']=$this->Model->get_all();
		$data['tbmahasiswa1']=$this->Model->get_by_id($id);
		$this->load->view('Update',$data);
	}
	
	public function update()
	{
		$Nim =$this->input->post('Nim');
		$Nama =$this->input->post('Nama');

            $data = array
				(
					'Nama'   =>$Nama,
				);
			$this->Model->update(array('Nim' =>$Nim), $data);
			redirect('Welcome');
        
	}
	
	public function delete_($no)
	{
	$this->Model->delete_id($no);
	redirect('Welcome');
	}
	
	
	
}
